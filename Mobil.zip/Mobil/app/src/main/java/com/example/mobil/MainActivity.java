package com.example.mobil;

import androidx.appcompat.app.AppCompatActivity;

import android.content.res.TypedArray;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
  //  private String[] datasmobil = {"Mobil Convertible", "Mobil Coupe", "Mobil Hatchback", "Mobil MPV", "Mobil Sport"};
    private MenuAdapter adapter;
    private String[] dataNama;
    private String[] dataDes;
    private TypedArray dataGambar;
    private ArrayList<Menu> menus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_main);
        ListView lvmobil = findViewById (R.id.lvmobil);
        adapter = new MenuAdapter (this);
        lvmobil.setAdapter (adapter);

        prepare ();
        tambahitem ();

        lvmobil.setOnItemClickListener (new AdapterView.OnItemClickListener () {

            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText (MainActivity.this, menus.get (i).getNama (), Toast.LENGTH_SHORT).show ();
            }
        });
    }

    private void prepare() {
        dataNama = getResources ().getStringArray (R.array.data_menu);
        dataDes = getResources ().getStringArray (R.array.data_deskripsi);
        dataGambar = getResources ().obtainTypedArray (R.array.data_gambar);
    }

    private void tambahitem() {
        menus = new ArrayList<> ();

        for (int i = 0; i < dataNama.length; i++) {
            Menu menu = new Menu ();
            menu.setGambar (dataGambar.getResourceId (i, -1));
            menu.setNama (dataNama[i]);
            menu.setDeskripsi (dataDes[i]);
            menus.add (menu);
        }
        adapter.setMenus (menus);
    }
}
