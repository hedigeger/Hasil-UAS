package com.example.mobil;

public class Menu {
    private int gambar;
    private String nama;
    private String Deskripsi;

    public int getGambar() {
        return gambar;
}
    public void setGambar(int gambar) {
        this.gambar = gambar;
    }
    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getDeskripsi() {
        return Deskripsi;
    }

    public void setDeskripsi(String deskripsi) {
        Deskripsi = deskripsi;
    }
}
